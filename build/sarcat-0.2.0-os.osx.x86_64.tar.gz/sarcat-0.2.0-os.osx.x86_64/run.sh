bin/node/bin/node index.js
