#!/bin/bash

bin/node/bin/node index.js