(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;
var moment = Package['momentjs:moment'].moment;



/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['tsega:bootstrap3-datetimepicker'] = {};

})();

//# sourceMappingURL=tsega_bootstrap3-datetimepicker.js.map
